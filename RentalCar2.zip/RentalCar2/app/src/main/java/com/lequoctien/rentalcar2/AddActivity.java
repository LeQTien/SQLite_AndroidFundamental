package com.lequoctien.rentalcar2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {
    EditText add_brand, add_price, add_location, add_type;
    Button save_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        add_brand = findViewById(R.id.add_brand);
        add_price = findViewById(R.id.add_price);
        add_location = findViewById(R.id.add_location);
        add_type = findViewById(R.id.add_type);
        save_button = findViewById(R.id.save_button);

        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);

                myDB.addCar(add_brand.getText().toString().trim(),
                        Float.valueOf(add_price.getText().toString().trim()),
                        add_location.getText().toString().trim(),
                        add_type.getText().toString().trim()
                        );
            }
        });
    }
}