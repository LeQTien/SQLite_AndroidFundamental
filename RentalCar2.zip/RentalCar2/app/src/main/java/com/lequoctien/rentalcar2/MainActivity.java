package com.lequoctien.rentalcar2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Button addCar;
    MyDatabaseHelper myDB;
    ArrayList<String> car_id, car_brand, car_price, car_location, car_type;
    MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addCar = findViewById(R.id.addCar);
        addCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        myDB = new MyDatabaseHelper(MainActivity.this);
        car_id = new ArrayList<>();
        car_brand = new ArrayList<>();
        car_price = new ArrayList<>();
        car_location = new ArrayList<>();
        car_type = new ArrayList<>();

        storeDataInArrays();
        myAdapter = new MyAdapter(MainActivity.this, car_id, car_brand, car_price, car_location, car_type);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }

    void storeDataInArrays() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                car_id.add(cursor.getString(0));
                car_brand.add(cursor.getString(1));
                car_price.add(cursor.getString(2));
                car_location.add(cursor.getString(3));
                car_type.add(cursor.getString(4));
            }
        }
        cursor.close(); // Đóng con trỏ sau khi sử dụng
    }
}