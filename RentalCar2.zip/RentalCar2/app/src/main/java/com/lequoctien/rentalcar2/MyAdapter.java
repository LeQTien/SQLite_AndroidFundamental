package com.lequoctien.rentalcar2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<String> car_id, car_brand, car_price, car_location, car_type;
    MyAdapter(Context context, ArrayList car_id, ArrayList car_brand, ArrayList car_price, ArrayList car_location, ArrayList car_type) {
        this.context = context;
        this.car_id = car_id;
        this.car_brand = car_brand;
        this.car_price = car_price;
        this.car_location = car_location;
        this.car_type = car_type;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {  // get all data from our array
        holder.car_id_txt.setText(String.valueOf(car_id.get(position)));
        holder.car_brand_txt.setText(String.valueOf(car_brand.get(position)));
        holder.car_price_txt.setText(String.valueOf(car_price.get(position)));
        holder.car_location_txt.setText(String.valueOf(car_location.get(position)));
        holder.car_type_txt.setText(String.valueOf(car_type.get(position)));
    }

    @Override
    public int getItemCount() {
        return car_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView car_id_txt, car_brand_txt, car_price_txt, car_location_txt, car_type_txt;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            car_id_txt = itemView.findViewById(R.id.car_id_txt);
            car_brand_txt = itemView.findViewById(R.id.car_brand_txt);
            car_price_txt = itemView.findViewById(R.id.car_price_txt);
            car_location_txt = itemView.findViewById(R.id.car_location_txt);
            car_type_txt = itemView.findViewById(R.id.car_type_txt);
        }
    }
}
