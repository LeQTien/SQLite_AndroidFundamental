// MainActivity.java
package com.lequoctien.cau1de4;


import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText numberInput;
    private Button confirmButton;
    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberInput = findViewById(R.id.numberInput);
        confirmButton = findViewById(R.id.confirmButton);
        gridLayout = findViewById(R.id.gridLayout);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView();
            }
        });
    }

    private void drawView() {
        String inputText = numberInput.getText().toString();
        if (TextUtils.isEmpty(inputText)) {
            return;
        }

        int numberOfItems = Integer.parseInt(inputText);
        gridLayout.removeAllViews(); // Clear the grid before redrawing
        gridLayout.setRowCount((numberOfItems + 2) / 3); // Set the number of rows dynamically

        new Thread(new Runnable() {
            @Override
            public void run() {
                Random random = new Random();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 0; i < numberOfItems; i++) {
                            TextView textView = new TextView(MainActivity.this);
                            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                            params.width = 0;
                            params.height = 150;
                            params.rowSpec = GridLayout.spec(i / 3, 1f);
                            params.columnSpec = GridLayout.spec(i % 3, 1f);
                            textView.setLayoutParams(params);
                            textView.setTextSize(25);
                            textView.setGravity(Gravity.CENTER);

                            params.setMargins(10,14,10,14);
                            textView.setTextColor(Color.WHITE);

                            int number = random.nextInt(10);
                            textView.setText(String.valueOf(number));

                            if (number % 2 == 0) {
                                textView.setBackgroundColor(Color.BLUE);
                            } else {
                                textView.setBackgroundColor(Color.GRAY);
                            }

                            gridLayout.addView(textView);
                        }
                    }
                });
            }
        }).start();
    }
}
