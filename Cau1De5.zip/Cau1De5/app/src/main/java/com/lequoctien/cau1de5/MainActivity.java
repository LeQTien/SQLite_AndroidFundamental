package com.lequoctien.cau1de5;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private GridLayout drawView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.et_number);
        drawView = findViewById(R.id.draw_view);

        etNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    int numRows = Integer.parseInt(s.toString());
                    new DrawTask().execute(numRows);
                }
            }
        });
    }

    private class DrawTask extends AsyncTask<Integer, Void, List<TextView[]>> {

        @Override
        protected List<TextView[]> doInBackground(Integer... integers) {
            int numRows = integers[0];
            List<TextView[]> rows = new ArrayList<>();

            List<Integer> numbers = new ArrayList<>();
            for (int i = 0; i <= 9; i++) {
                numbers.add(i);
            }
            Collections.shuffle(numbers);

            // Chuyển đổi từ dp sang px
            int marginInDp = 10;
            int widthInDp = 60; // Chỉnh lại width
            int heightInDp = 60; // Chỉnh lại height
            int marginInPx = (int) (marginInDp * getResources().getDisplayMetrics().density);
            int widthInPx = (int) (widthInDp * getResources().getDisplayMetrics().density);
            int heightInPx = (int) (heightInDp * getResources().getDisplayMetrics().density);

            for (int i = 0; i < numRows; i++) {
                TextView[] row = new TextView[2];

                TextView tv1 = new TextView(MainActivity.this);
                TextView tv2 = new TextView(MainActivity.this);

                GridLayout.LayoutParams params1 = new GridLayout.LayoutParams();
                params1.columnSpec = GridLayout.spec(i % 2 == 0 ? 0 : 1, 2f);
                params1.setMargins(marginInPx, marginInPx, marginInPx, marginInPx); // Thiết lập margin
                params1.width = widthInPx; // Thiết lập width
                params1.height = heightInPx; // Thiết lập height

                tv1.setLayoutParams(params1);

                GridLayout.LayoutParams params2 = new GridLayout.LayoutParams();
                params2.columnSpec = GridLayout.spec(i % 2 == 0 ? 1 : 0, 1f);
                params2.setMargins(marginInPx, marginInPx, marginInPx, marginInPx); // Thiết lập margin
                params2.width = widthInPx; // Thiết lập width
                params2.height = heightInPx; // Thiết lập height
                tv2.setLayoutParams(params2);

                int index1 = i * 2 % 10;
                int index2 = (i * 2 + 1) % 10;

                tv1.setText(String.valueOf(numbers.get(index1)));
                tv2.setText(String.valueOf(numbers.get(index2)));

                tv1.setBackgroundColor(numbers.get(index1) % 2 == 0 ? Color.BLUE : Color.GRAY);
                tv2.setBackgroundColor(numbers.get(index2) % 2 == 0 ? Color.BLUE : Color.GRAY);

                // Đổi màu chữ số trong TextView
                tv1.setTextColor(numbers.get(index1) % 2 == 0 ? Color.GREEN : Color.RED);
                tv2.setTextColor(numbers.get(index2) % 2 == 0 ? Color.GREEN : Color.RED);

                row[0] = tv1;
                row[1] = tv2;

                rows.add(row);
            }

            return rows;
        }

        @Override
        protected void onPostExecute(List<TextView[]> rows) {
            drawView.removeAllViews();
            for (TextView[] row : rows) {
                for (TextView tv : row) {
                    drawView.addView(tv);
                }
            }
        }
    }
}
